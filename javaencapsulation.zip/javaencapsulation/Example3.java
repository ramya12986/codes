package com.avensys.javaencapsulation;

class Student{
	
	private String name;
	private String idNum;
	private int age;
	// getter and setter method for all the private members
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdNum() {
		return idNum;
	}
	public void setIdNum(String idNum) {
		this.idNum = idNum;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}

public class Example3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating object for student class
		Student s = new Student();
		s.setAge(20);
		s.setIdNum("12");
		s.setName("Ramya");
		System.out.println(s.getAge());
		System.out.println(s.getIdNum());
		System.out.println(s.getName());

	}

}
