package com.avensys.javaencapsulation;

class Book{
	private int pgno;
	
	//Constructors
	Book(int pgno)
	{
		  if(pgno>0)
		  {
		    this.pgno = pgno;  // Shadowing problem in java
	      }
		  else
		  {
			  System.out.println("page no cannot be negative");
			  System.exit(0);
		  }
	}
	

	int getData()
	{
	   return pgno;
	}
}
public class Example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Book b = new Book(100);
     
      System.out.println("page no is :" + b.getData());
      
	}

}
