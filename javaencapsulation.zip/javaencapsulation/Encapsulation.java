package com.avensys.javaencapsulation;

class Palani{
	int acno;
	 int pwd;
	void display() {
		System.out.println(acno);
		System.out.println(pwd);
	}
}
class Ramya{
	Palani p = new Palani();
	void accessPalaniDetails() {
		System.out.println("Ramya has acno: "+p.acno);
		System.out.println("ramya has pwd:"+p.pwd);
		
	}
	void changeDeatils() {
		System.out.println("Ramya Changing Details");
		p.acno=12345;
		p.pwd=123456;
		System.out.println("Ramya Changed accno:" +p.acno);
		System.out.println("Ramya Changed pwd:" +p.pwd);
		
		
	}
}

public class Encapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Ramya r= new Ramya();
      r.accessPalaniDetails();
      r.changeDeatils();
	}

}
