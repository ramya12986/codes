package com.avensys.javaconstructors;

public class Student1 {
	int id;
	String name;
	void display()
	{
		System.out.println(id+" "+name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student1 s1= new Student1();
		Student1 s2 = new Student1();
		s1.display();
		s2.display();

	}

}
