package com.avensys.javaconstructors;

public class Bike {
	Bike(){
		System.out.println("Bike is created");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bike b = new Bike();
		

	}

}
