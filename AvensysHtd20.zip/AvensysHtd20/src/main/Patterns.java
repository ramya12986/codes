package main;

public class Patterns {

	public static void main(String[] args) {
		
		for(int r=1; r<=30; r++) {
			for(int c=1; c<=30; c++) {
				if ( r<=10 && ((c >=6 && c<=10) || (c>=21 && c<=25)) ) {
					System.out.print("  ");
				} else if((r>=26 && r<=30) && (c>=6 && c<=25)) {
					System.out.print("  ");
				} else if(
						
						(r<=5 && (c>=1 && c<=5-r)) || 
						(r<=4 && (c>=26+r && c<=30)) || 
						((r>=26 && r<=30) && c <= r-26) ||
						(r<=4 && (c>10+r && c<=15)) ||
						(r<=5 && (c>=16 && c<=20-r))||
						((r>=11) && (r<=15) && (c>6+r && c<=10))                     
						
						) {
					System.out.print("  ");
				}
				
				else {
					System.out.print("* ");
				}
			}
			System.out.println();
		}
	}

}
