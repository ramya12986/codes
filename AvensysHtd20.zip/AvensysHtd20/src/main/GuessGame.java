package main;

import java.util.Scanner;

class Guesser
{
	int gNum;
	int genNum()
	{
		System.out.println("Guesser guess a number");
		Scanner sc= new Scanner(System.in);
				gNum=sc.nextInt();
		return gNum;
	}
}
class Player
{
	int pNum;
	int genNum()
	{
		System.out.println("Player guess a number");
		Scanner sc= new Scanner(System.in);
				pNum=sc.nextInt();
		return pNum;
	}
}
class Umpire
{
	int noFromP1;
	int noFromP2;
	int noFromP3;
	int noFromGuesser;
	
	void askGuesser() {
		Guesser g= new Guesser();
		noFromGuesser=g.genNum();
		}
	void askPlayers() {
		Player p1=new Player();
		Player p2=new Player();
		Player p3=new Player();
		noFromP1=p1.genNum();
		noFromP2=p2.genNum();
		noFromP3=p3.genNum();
		
		}
	void askCompare() {
		if(noFromGuesser == noFromP1 && noFromGuesser == noFromP2 && noFromGuesser == noFromP3)
		{
			System.out.println("All 3 guessed Correctly");
		}
		else if(noFromGuesser == noFromP1)
		{
			System.out.println("P1 is the winner");
		}
		else if(noFromGuesser == noFromP2)
		{
			System.out.println("P2 is the winner");
		}
		else if(noFromGuesser == noFromP3)
		{
			System.out.println("P3 is the winner");
		}
		else
		{
			System.out.println("Its a draw.No one guessed Correectly");
		}
	}
	
}
public class GuessGame {

	public static void main(String[] args) {
		Umpire u= new Umpire();
		u.askGuesser();
		u.askPlayers();
		u.askCompare();
		
		

	}

}
