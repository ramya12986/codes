package main;

public class Test {
	

		public static void main(String[] args) {
			for(int j=1; j<=5; j++) // rows
			{
				for(int i=5;i>=j;i--) //space
				{
					System.out.print(" ");
				}
				for(int i=1;i<=j;i++)//stars
				{
					System.out.print("*");
				}
				for(int i=1;i<=5;i++)
				{
					System.out.print(" ");
				}
				for(int i=1;i<=j;i++)//stars
				{
					System.out.print("*");
				}
				System.out.println();
			}
			for(int j=1;j<=5;j++)
			{
				for(int i=1;i<=6;i++)
				{
					System.out.print(" ");
				}
					for(int i=1;i<=5;i++)
					{
						System.out.print("*");
					}
					System.out.println();
			}
			for(int j=1; j<=5; j++) // rows
			{
				for(int i=1;i<=j;i++) //space
				{
					System.out.print(" ");
				}
				for(int i=5;i>=j;i--)//stars
				{
					System.out.print("*");
				}
				for(int i=1;i<=5;i++)
				{
					System.out.print(" ");
				}
				for(int i=5;i>=j;i--)//stars
				{
					System.out.print("*");
				}
				System.out.println();
			}
		}

	}


