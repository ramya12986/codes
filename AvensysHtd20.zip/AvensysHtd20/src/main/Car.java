package main;


class Cars {
	String brand;
	String model;
	int milage;
	void display() {
		System.out.println(brand);
		System.out.println(model);
		System.out.println(milage);
			}
	void start() {
		System.out.println("Started");
	}

   void move() {
		System.out.println("Moving");
	}
    void accelerateFast( ) {
    	System.out.println("Fast");
    }
    void stop() {
    	System.out.println("Stop");
    	}

	
}

public class Car {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cars c= new Cars();
		c.brand ="TATA";
		c.model="ABC";
		c.milage=100;
		c.start();
		c.move();
		c.accelerateFast();
		c.stop();
		c.display();
		


	}

}
