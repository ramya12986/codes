package com.avensys.javastrings;

public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      String s1 = "Java" ;
      String s2 = " java";
      //this objects created in constant pool so duplicate is not allowed
      if(s1.equals(s2)) {
    	  System.out.println("Ref are equal");
      }
      else {
    	  System.out.println("Ref are not equal");
      }
	}

}
