package com.avensys.javainterface;

interface Animal {

        void eat();
        void travel();
        
        
	}


