package com.avensys.javainterface;


class  Brain
{
	private int IQ;
	Brain(int IQ)
	{
		this.IQ=IQ;
	}
	public int getIQ() {
		return IQ;
	}
}


class Heart {
	private int heartBeat;
	Heart(int heartBeat)
	{
		this.heartBeat=heartBeat;
	}
	public int getHeartBeat() {
		return heartBeat;
	}
}

class Laptop
{
	String brand;
	int price;
	
	Laptop(String brand, int price)
	{
		this.brand=brand;
		this.price=price;
	}

	public String getBrand() {
		return brand;
	}
	
	public int getPrice() {
		return price;
	}
}

class Book

{
	String author;
	Book(String author)
	{
		this.author=author;
		
	}
	public String getAuthor() {
		return author;
	}
}

class Human{
	Brain brain = new Brain(86);
	Heart heart = new Heart(70);

	void hasA(Laptop lap)
	{
		System.out.println(lap.getBrand());
		System.out.println(lap.getPrice());
	}
	
	void hasA(Book book)
{
	System.out.println(book.getAuthor());

}

}
public class HumanExample {
	public static void main(String args[]) {

	Laptop lap = new Laptop("DELL", 3000);
	Book book=new Book("Ramya");
	
	Human h = new Human();
	h.hasA(lap);
	h.hasA(book);
	System.out.println(h.brain.getIQ());
	System.out.println(h.heart.getHeartBeat());	
	
	h=null;
	System.out.println("Human is no more");
//	h.hasA(lap);
//	h.hasA(book);
//	System.out.println(h.brain.getIQ());
//	System.out.println(h.heart.getHeartBeat());	
//	
	System.out.println("Accessing the laptop and book directly");
	System.out.println(lap.getBrand());
	System.out.println(lap.getPrice());
	System.out.println(book.getAuthor());

	
	
	
}

}
